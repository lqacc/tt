# Netflix Clone
A clone website of Netflix built with HTML, CSS & JS. 

![Screenshot 2022-04-14 at 00-41-32 Netflix - Watch TV Shows Online Watch Movies Online](https://user-images.githubusercontent.com/77227201/163253259-30da86a3-3fd0-432e-a6b5-fcc8f5db187b.png)
